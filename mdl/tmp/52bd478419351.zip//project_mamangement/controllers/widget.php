<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * <p style="text-align:justify">
 * Controller for widget generator
 * </p>
 * @package Computer_Programming_Services
 * @subpackage Controller
 * @category Controller
 * @property CI_Session $session CI session library
 * @property CI_Input $input Input object
 * @author YOUR NAME (YOUR EMAIL ADDRESS)
 * @license http://www.softwaredeveloperpro.com Software developer pro
 * @copyright (c) 2012, Software developer pro
 * @link http://www.softwaredeveloperpro.com
 */
class Widget extends G_controller {
    public function __construct(){
         parent::__construct(get_class());
         
    }
    
    public function index(){
        echo "Dfdf";
    }
}

?>
