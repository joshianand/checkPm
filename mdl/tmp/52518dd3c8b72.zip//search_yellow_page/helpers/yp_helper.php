<?php

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

if (!function_exists('grab_from_title')) {

    /**

     * <p style="text-align:justify">

     * Attempts to grab email address(es) from title tag of a html document

     * </p>

     * @author Mizanur Islam Laskar <cicakemizan@gmail.com>

     * @param string $html home-page html

     * @return mixed Returns scrapped emails or any failure status

     */
    function grab_from_title($html) {
        if (!preg_match('/<title>(.*)<\/title>/', $html, $contents)) {
            preg_match('/<TITLE>(.*)<\/TITLE>/', $html, $contents);
        }

        $grabbed_emails = false;

        if (count($contents) > 0) {
            $data = $contents[1];

            if ($data != '301 Moved Permanently') {
                $email_address_pattern = "([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})";
                if (preg_match('/' . $email_address_pattern . '/', $data, $list)) {
                    $grabbed_emails = $list[0];
                }
            }
        }


        return $grabbed_emails;
    }

}


if (!function_exists('grab_from_meta')) {

    /**

     * <p style="text-align:justify">

     * Attempts to grab email address(es) from meta keyword/description of a html document

     * </p>

     * @author Mizanur Islam Laskar <cicakemizan@gmail.com>

     * @param string $html home-page html

     * @return mixed Returns scrapped emails or false for failure attempts

     */
    function grab_from_meta($html) {
        $grabbed_emails = false;

        if (!preg_match('/<meta name="keywords" content="(.*)" \/> /i', $html, $contents)) {
            preg_match('/<meta name="description" content="(.*)" \/> /i', $html, $contents);
        }

        if ($contents) {
            $data = $contents[1];

            $email_address_pattern = "([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})";
            if (preg_match('/' . $email_address_pattern . '/', $data, $list)) {
                $grabbed_emails = $list[0];
            }
        }//end main if

        return $grabbed_emails;
    }

}


if (!function_exists('get_text_between_tags')) {

    /**

     * <p style="text-align:justify">

     * Gets all the inner contents of a specified html tag of a html document

     * </p>

     * @author Mizanur Islam Laskar <cicakemizan@gmail.com>

     * @param string $html home-page html
     * @param string $tag html tag
     * @param mixed $filter excluding any special text

     * @return array Returns matched contents of the chosen tag

     */
    function get_text_between_tags($html, $tag, $filter = '') {
        $dom = new DOMDocument;
        // the array to return
        $texts = array();

        if ($html) {
            // loads the html into the object
            $dom->loadHTML($html);

            // discards white space
            $dom->preserveWhiteSpace = false;

            // the tag by its tag name
            $content = $dom->getElementsByTagname($tag);


            foreach ($content as $item) {
                $node_value = $item->nodeValue;

                // adds node value to the $texts array
                if (!empty($filter) && $node_value != $filter) {
                    $texts[] = $node_value;
                } else {
                    $texts[] = $node_value;
                }
            }
        }


        return $texts;
    }

}


if (!function_exists('get_attribute_value_by_tag')) {

    /**

     * <p style="text-align:justify">

     * Gets all the inner contents of a specified html tag of a html document

     * </p>

     * @author Mizanur Islam Laskar <cicakemizan@gmail.com>

     * @param string $html home-page html
     * @param string $tag html tag
     * @param mixed $filter excluding any special text

     * @return array Returns matched contents of the chosen tag

     */
    function get_attribute_value_by_tag($html, $tag, $attribute_name) {
        $attribute_values = array();

        $dom = new DOMDocument;

        if ($html) {
            // loads the html into the object
            $dom->loadHTML($html);

            // grab all the doms on the page
            $xpath = new DOMXPath($dom);

            //finding the a tag
            $tags = $xpath->evaluate("/html/body//" . $tag);

            //Loop to display all the links
            for ($i = 0; $i < $tags->length; $i++) {
                if ($attribute_name == 'href') {
                    $href = $tags->item($i);
                    $url = $href->getAttribute('href');
                    if ($url != "#") {
                        $attribute_values[] = $url;
                    }
                }
            }
        }


        return $attribute_values;
    }

}


if (!function_exists('grab_from_homepage')) {

    /**

     * <p style="text-align:justify">

     * Attempts to grab email address(es) from inside the body contents of a html document

     * </p>

     * @author Mizanur Islam Laskar <cicakemizan@gmail.com>

     * @param string $html home-page html

     * @return mixed Returns scrapped emails or false for failure attempts

     */
    function grab_from_homepage($html) {
        $grabbed_emails = array();

        $hyperlinks = get_text_between_tags($html, 'a', '#');

        if (count($hyperlinks)) {
            $email_address_pattern = "([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})";

            for ($i = 0; $i < count($hyperlinks); $i++) {
                if (preg_match('/' . $email_address_pattern . '/', $hyperlinks[$i])) {
                    $grabbed_emails[] = $hyperlinks[$i];
                }
            }
        }//end if

        if (count($grabbed_emails)) {
            return $grabbed_emails;
        } else {
            return false;
        }
    }

}


if (!function_exists('grab_from_contact_page')) {

    /**

     * <p style="text-align:justify">

     * Attempts to grab email address(es) from inside the body contents of a html document

     * </p>

     * @author Mizanur Islam Laskar <cicakemizan@gmail.com>

     * @param string $html home-page html
     * @param string $domain_url web URL

     * @return mixed Returns scrapped emails or false for failure attempts

     */
    function grab_from_contact_page($html, $domain_url) {
        $grabbed_emails = array();

        $contact_url = '';

        $href_values = get_attribute_value_by_tag($html, 'a', 'href');

        if (count($href_values)) {
            for ($i = 0; $i < count($href_values); $i++) {
                if (preg_match('/contact/', $href_values[$i])) {
                    $contact_url = $href_values[$i];
                    break;
                }
            }

            if (!empty($contact_url)) {
                $contact_page_url = $domain_url . '/' . $contact_url;

                $contact_page_html = curl($contact_page_url);

                $hyperlinks = get_text_between_tags($contact_page_html, 'a', '#');

                if (count($hyperlinks)) {
                    $email_address_pattern = "([a-z0-9_\.-]+)@([\da-z\.-]+)\.([a-z\.]{2,6})";

                    for ($i = 0; $i < count($hyperlinks); $i++) {
                        if (preg_match('/' . $email_address_pattern . '/', $hyperlinks[$i])) {
                            $grabbed_emails[] = $hyperlinks[$i];
                        }
                    }
                }//end if
            }//end sub-if
        }//end main-if

        if (count($grabbed_emails)) {
            return $grabbed_emails;
        } else {
            return false;
        }
    }

}

if (!function_exists('curl')) {

    /**

     * <p style="text-align:justify">

     * Defines the basic cURL function

     * </p>

     * @author Mizanur Islam Laskar <cicakemizan@gmail.com>

     * @param string $url Domain URL

     * @return string Returns scrapped html string

     */
    function curl($url) {
        $ch = curl_init();  // Initialising cURL

        curl_setopt($ch, CURLOPT_URL, $url);    // Setting cURL's URL option with the $url variable passed into the function

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE); // Setting cURL's option to return the webpage data

        $data = curl_exec($ch); // Executing the cURL request and assigning the returned data to the $data variable

        curl_close($ch);    // Closing cURL

        return $data;   // Returning the data from the function
    }

}

if (!function_exists('scrap_emails')) {

    /**

     * <p style="text-align:justify">

     * Scrap contact email addresses from the given website

     * </p>

     * @author Mizanur Islam Laskar <cicakemizan@gmail.com>

     * @param string $domain_url Domain URL

     * @return array Returns scrapped emails array

     */
    function scrap_emails($domain_url) {
        $domain_url_initial = substr($domain_url, 0, 7);

        if ($domain_url_initial != 'http://') {
            $domain_url = 'http://' . $domain_url;
        }

        $html = curl($domain_url);

        $grabbed_emails = false;

        //attempts from title-tag
        $grabbed_emails = grab_from_title($html);

        if (!is_array($grabbed_emails)) {
            //attempts to grab from meta-keywords/description if fails from title
            $grabbed_emails = grab_from_meta($html);
        }

        if (!is_array($grabbed_emails)) {
            //attempts to grab from the home-page if fails from meta-description
            $grabbed_emails = grab_from_homepage($html);
        }

        if (!is_array($grabbed_emails)) {
            //finally attempts to grab from the contact information page if fails even from the home-page
            $grabbed_emails = grab_from_contact_page($html, $domain_url);
        }

        return $grabbed_emails;
    }

}

if (!function_exists('extract_pagination_count')) {

    /**
     * <p style="text-align:justify">
     * Extract pagination counts
     * </p>
     * @author Pronab Saha <pranab.su@gmail.com>
     * @param mixed $pagination_string Pagination string
     * @return array Returns Pagination count array
     */
    function extract_pagination_count($pagination_string = '') {
        $pagination_string = trim($pagination_string);
        preg_match_all('!\d+!', $pagination_string, $matches);
        return $matches[0];
    }

}