<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/**
 * <p style="text-align:justify">
 * Controller for yellow page search
 * </p>
 * @package Computer_Programming_Services
 * @subpackage Controller
 * @category Controller
 * @property CI_Session $session CI session library
 * @property CI_Input $input Input object
 * @author Pronab saha (pranab.su@gmail.com)
 * @license http://www.softwaredeveloperpro.com Software developer pro
 * @copyright (c) 2012, Software developer pro
 * @link http://www.softwaredeveloperpro.com
 */
class Ypsearch extends G_Controller {

    /**
     * Class constructor
     * @access public
     */
    public function __construct() {
        parent::__construct(get_class());

        $this->load->model('module_models/search_yellow_page/Model_yp', 'yp_model');
        $this->load->library(array(
            'excel',
            'module_libraries/search_yellow_page/yellowapi'
        ));
        $this->load->helper('modules/search_yellow_page/yp');
    }

    /**
     * @access public
     */
    public function index() {
        $page_data['token'] = $this->token;
        $page_data['cities'] = $this->yp_model->getCities();
        $this->construct_ui();
        $this->template->write_view('content', 'module_views/search_yellow_page/index', $page_data);
        $this->template->render();
    }

    /**
     * <p style="text-align:justify">
     * Get search data
     * </p>
     * @access public
     * @author Pronab saha<pranab.su@gmail.com>
     */
    public function GetSearchList() {
        if (IS_AJAX) {
            $limit = $this->input->get('take', TRUE);
            $offset = $this->input->get('skip', TRUE);

            $sort_data = $this->input->get('sort', TRUE);

            $sort_direction = ( $sort_data[0]['dir'] == '') ? 'desc' : $sort_data[0]['dir'];
            $sort_field = ( $sort_data[0]['field'] == '') ? 'search_id' : $sort_data[0]['field'];

            $data['search_data'] = $this->yp_model->GetSearchList($limit, $offset, $sort_direction, $sort_field);
            $data['count'] = $this->yp_model->CountSearchList();

            echo json_encode($data);
        } else {
            show_error('Sorry, direct access isnt allowed');
        }
    }

    /**
     * <p style="text-align:justify">
     * Get business details data
     * </p>
     * @access public
     * @author Pronab saha<pranab.su@gmail.com>
     */
    public function GetBusinessDetails() {
        if (IS_AJAX) {
            $search_id = $this->input->get('search_id', TRUE);
            $limit = $this->input->get('take', TRUE);
            $offset = $this->input->get('skip', TRUE);

            $sort_data = $this->input->get('sort', TRUE);

            $sort_direction = ( $sort_data[0]['dir'] == '') ? 'desc' : $sort_data[0]['dir'];
            $sort_field = ( $sort_data[0]['field'] == '') ? 'business_id' : $sort_data[0]['field'];

            $data['business_details'] = $this->yp_model->GetBusinessDetails($search_id, $limit, $offset, $sort_direction, $sort_field);
            $data['count'] = $this->yp_model->CountBusinessDetails($search_id);

            echo json_encode($data);
        } else {
            show_error('Sorry, direct access isnt allowed');
        }
    }

    /**
     * <p style="text-align:justify">
     * Processing saving searched data
     * </p>
     * @access public
     * @author Pronab saha<pranab.su@gmail.com>
     */
    public function SaveYellowPageSearch() {
        if ($this->input->is_ajax_request()) {
            set_time_limit(0);
            $search_list = array();

            $output_result = array();
            $output_result['flag'] = 1;
            $output_result['message'] = "Scraping done. Please click left most triangle of row to expand scrape result";

            $city_selection = $this->input->post('citySelection', TRUE);
            $search_text = $this->input->post('searchText', TRUE);
            $city_name = $this->yp_model->GetCityName($city_selection);

            if ($this->yp_model->IsDuplicateWhatWhere($city_selection, $search_text)) {
                $output_result['flag'] = 0;
                $output_result['message'] = "Duplicate city and search text found. Please choose another combination";
            } else {
                $data = array(
                    'city_id' => $city_selection,
                    'city_name' => $city_name,
                    'search_text' => $search_text,
                    'total_business_found' => 0,
                    'search_status' => 'pending',
                    'modified_date' => strtotime('now')
                );

                array_push($search_list, $data);
                $this->BasicBusinessSearch($search_list);
            }
            echo json_encode($output_result);
        } else {
            show_error('Sorry, direct access isnt allowed');
        }
    }

    /**
     * <p style="text-align:justify">
     * Processing scrape emails
     * </p>
     * @access public
     * @author Pronab saha<pranab.su@gmail.com>
     */
    public function ScrapeEmails() {
        if (IS_AJAX) {
            set_time_limit(0);
            libxml_use_internal_errors(true);

            $output_result = array();
            $output_result['flag'] = 1;

            $search_id = $this->input->post('search_id', TRUE);
            $business_sites = $this->yp_model->GetBusinessWebsites($search_id);

            if (count($business_sites) > 0) {
                $total_scraped = 0;
                
                foreach ($business_sites as $site) {
                    $domain = $site['company_url'];
                    
                    $scrapped_emails = scrap_emails($domain);
                    if (is_array($scrapped_emails)) {
                        if (count($scrapped_emails) > 1) {
                            $contact_emails = join(',', $scrapped_emails);
                        } else {
                            $contact_emails = $scrapped_emails[0];
                        }
                        
                        $this->yp_model->UpdateVerifiedEmail($site['business_id'], $contact_emails);
                    }
                    
                    $total_scraped += count($scrapped_emails);
                }
                
                $this->yp_model->UpdateScrapeStatus($search_id);
                $output_result['message'] = "Total $total_scraped emails scraped successfully";
            } else {
                $output_result['flag'] = 0;
                $output_result['message'] = 'No website found to generate email address';
            }
            echo json_encode($output_result);
        } else {
            show_error('Sorry, direct access is not allowed');
        }
    }

    /**
     * <p style="text-align:justify">
     * Processing removing data
     * </p>
     * @access public
     * @author Pronab saha<pranab.su@gmail.com>
     */
    public function DeleteYellowSearch() {
        if (IS_AJAX) {
            $search_id = $this->input->post('search_id', TRUE);
            if ($this->yp_model->UpdateSearchData(NULL, -1, $search_id) === TRUE) {
                echo "1*Search query deleted successfully";
            } else {
                echo "0*An error occur while deleting.";
            }
        } else {
            show_error('Sorry, direct access isnt allowed');
        }
    }

    /**
     * <p style="text-align:justify">
     * Processing downloading data
     * </p>
     * @access public
     * @author Pronab saha<pranab.su@gmail.com>
     */
    public function DownloadSearchResults() {
        $search_id = $this->input->get('search_id', TRUE);

        $this->excel->setActiveSheetIndex(0);
        $this->excel->getActiveSheet()->setTitle('Business listings');

        $businesses = $this->yp_model->GetBusinessDetails($search_id, 0, 0);

        if (count($businesses) > 0) {
            $this->excel->getActiveSheet()->setCellValue('A1', 'Business name')->getStyle('A1')->getFont()->setBold(true);
            $this->excel->getActiveSheet()->setCellValue('B1', 'Category')->getStyle('B1')->getFont()->setBold(true);
            $this->excel->getActiveSheet()->setCellValue('C1', 'Address')->getStyle('C1')->getFont()->setBold(true);
            $this->excel->getActiveSheet()->setCellValue('D1', 'City')->getStyle('D1')->getFont()->setBold(true);
            $this->excel->getActiveSheet()->setCellValue('E1', 'State')->getStyle('E1')->getFont()->setBold(true);
            $this->excel->getActiveSheet()->setCellValue('F1', 'Zip')->getStyle('F1')->getFont()->setBold(true);
            $this->excel->getActiveSheet()->setCellValue('G1', 'Phone')->getStyle('G1')->getFont()->setBold(true);
            $this->excel->getActiveSheet()->setCellValue('H1', 'Website')->getStyle('H1')->getFont()->setBold(true);
            $this->excel->getActiveSheet()->setCellValue('I1', 'Emails')->getStyle('I1')->getFont()->setBold(true);
            $this->excel->getActiveSheet()->setCellValue('J1', 'Average rating')->getStyle('J1')->getFont()->setBold(true);

            $count = 2;
            foreach ($businesses as $business) {
                $this->excel->getActiveSheet()->setCellValue('A' . $count, element('business_name', $business));
                $this->excel->getActiveSheet()->setCellValue('B' . $count, element('business_category', $business));
                $this->excel->getActiveSheet()->setCellValue('C' . $count, element('street_address', $business));
                $this->excel->getActiveSheet()->setCellValue('D' . $count, element('city', $business));
                $this->excel->getActiveSheet()->setCellValue('E' . $count, element('state', $business));
                $this->excel->getActiveSheet()->setCellValue('F' . $count, element('post_code', $business));
                $this->excel->getActiveSheet()->setCellValue('G' . $count, element('phone', $business));
                $this->excel->getActiveSheet()->setCellValue('H' . $count, element('company_url', $business));
                $this->excel->getActiveSheet()->setCellValue('I' . $count, element('emails', $business));
                $this->excel->getActiveSheet()->setCellValue('J' . $count, element('average_rating', $business));

                if ($count % 2 > 0) {
                    $cells = "A$count:P$count";
                    $color = "d6d6d6";

                    $this->excel->getActiveSheet()->getStyle($cells)->getFill()->applyFromArray(
                            array('type' => PHPExcel_Style_Fill::FILL_SOLID,
                                'startcolor' => array('rgb' => $color)
                    ));
                }

                $count++;
            }

            $this->excel->getActiveSheet()->getColumnDimension('A')->setAutoSize(true);
            $this->excel->getActiveSheet()->getColumnDimension('B')->setAutoSize(true);
            $this->excel->getActiveSheet()->getColumnDimension('C')->setAutoSize(true);
            $this->excel->getActiveSheet()->getColumnDimension('D')->setAutoSize(true);
            $this->excel->getActiveSheet()->getColumnDimension('E')->setAutoSize(true);
            $this->excel->getActiveSheet()->getColumnDimension('F')->setAutoSize(true);
            $this->excel->getActiveSheet()->getColumnDimension('G')->setAutoSize(true);
            $this->excel->getActiveSheet()->getColumnDimension('H')->setAutoSize(true);
            $this->excel->getActiveSheet()->getColumnDimension('I')->setAutoSize(true);
            $this->excel->getActiveSheet()->getColumnDimension('J')->setAutoSize(true);

            $filename = $this->yp_model->GetDownloadFileName($search_id);
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment;filename="' . $filename . '"');
            header('Cache-Control: max-age=0');
            $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');
            $objWriter->save('php://output');
        } else {
            show_error('Sorry no data found');
        }
    }

    /**
     * <p style="text-align:justify">
     * Search business list
     * </p>
     * @access public
     * @author Pronab saha<pranab.su@gmail.com>
     */
    protected function BasicBusinessSearch($search_list = array()) {
        foreach ($search_list as $search) {
            $business_details = array();

            $what = $search['search_text'];
            $where = $search['city_name'];

            $total_business_found = 0;
            $page_count = 2;

            $businesses = $this->yellowapi->scrap_business($what, $where, 1);

            $listings = $businesses['details'];
            $pagination_string = $businesses['pagination_text'];

            if (count($listings) > 0) {
                $search_id = $this->yp_model->InsertSearchData($search);

                foreach ($listings as $list) {
                    $data = array(
                        'search_id' => $search_id,
                        'business_name' => $list['business_name'],
                        'business_category' => $list['business_category'],
                        'street_address' => $list['street_address'],
                        'city' => $list['city'],
                        'state' => $list['state'],
                        'post_code' => $list['post_code'],
                        'phone' => $list['phone'],
                        'company_url' => $list['company_url'],
                        'emails' => '',
                        'average_rating' => $list['average_rating']
                    );

                    array_push($business_details, $data);
                }
            }

            if ($pagination_string) {
                $pagination_count = extract_pagination_count($pagination_string);

                $start_count = (int) $pagination_count[0];
                $end_count = (int) $pagination_count[1];
                $total_count = (int) $pagination_count[2];

                $total_business_found += ($end_count - $start_count) + 1;
            } else {
                $end_count = $total_business_found = $total_count = 0;
            }

            while ($end_count < $total_count) {
                sleep(rand(3, 5));

                $businesses = $this->yellowapi->scrap_business($what, $where, $page_count);

                $listings = $businesses['details'];
                $pagination_string = $businesses['pagination_text'];

                if (count($listings) > 0) {
                    foreach ($listings as $list) {
                        $data = array(
                            'search_id' => $search_id,
                            'business_name' => $list['business_name'],
                            'business_category' => $list['business_category'],
                            'street_address' => $list['street_address'],
                            'city' => $list['city'],
                            'state' => $list['state'],
                            'post_code' => $list['post_code'],
                            'phone' => $list['phone'],
                            'company_url' => $list['company_url'],
                            'emails' => '',
                            'average_rating' => $list['average_rating']
                        );

                        array_push($business_details, $data);
                    }

                    $pagination_count = extract_pagination_count($pagination_string);
                    $start_count = $pagination_count[0];
                    $end_count = $pagination_count[1];
                    $total_count = $pagination_count[2];
                    $total_business_found += ($end_count - $start_count) + 1;
                } else {
                    break;
                }
                $page_count++;
            }

            $update_data = array(
                'total_business_found' => $total_business_found,
                'search_status' => 'completed'
            );

            $this->yp_model->UpdateSearchData($update_data, 0, $search_id);
            $this->yp_model->InsertSearchDetailsData($business_details);
        }
    }

}

/* End of file  ypsearch.php */
/* Location: ./application/controllers/ypsearch.php */
