#
# TABLE STRUCTURE FOR: yellow_page_search_lists
#

DROP TABLE IF EXISTS yellow_page_search_lists;

CREATE TABLE `yellow_page_search_lists` (
  `search_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Primary identification key',
  `city_id` bigint(20) NOT NULL COMMENT 'City reference',
  `city_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Name of location/city',
  `search_text` varchar(500) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Search text',
  `total_business_found` int(11) DEFAULT '0' COMMENT 'Total business found',
  `search_status` enum('pending','cancelled','completed') COLLATE utf8_unicode_ci DEFAULT 'pending' COMMENT 'Search status',
  `email_scraped` enum('yes','no') COLLATE utf8_unicode_ci DEFAULT 'no',
  `modified_date` bigint(20) DEFAULT NULL COMMENT 'Modified date',
  PRIMARY KEY (`search_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

#
# TABLE STRUCTURE FOR: yellow_page_business_details
#

DROP TABLE IF EXISTS yellow_page_business_details;

CREATE TABLE `yellow_page_business_details` (
  `business_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Primary identification key',
  `search_id` bigint(20) DEFAULT NULL COMMENT 'Search reference',
  `listing_id` bigint(20) DEFAULT NULL COMMENT 'Yellow page listing id',
  `business_name` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Business name',
  `business_name_url` int(11) DEFAULT NULL COMMENT 'Business name url',
  `business_category` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Business category',
  `street_address` text COLLATE utf8_unicode_ci COMMENT 'Street address',
  `city` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'City name',
  `state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'State name',
  `post_code` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Post code',
  `latitude` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'latitude',
  `longitude` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'longitude',
  `phone` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Phone',
  `company_url` text COLLATE utf8_unicode_ci COMMENT 'Company url',
  `coupon_url` text COLLATE utf8_unicode_ci COMMENT 'Coupon url',
  `emails` text COLLATE utf8_unicode_ci COMMENT 'Email list',
  `open_hours` text COLLATE utf8_unicode_ci COMMENT 'Open hours',
  `payment_methods` text COLLATE utf8_unicode_ci COMMENT 'Accepted payment methods',
  `average_rating` varchar(20) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'Average rating',
  `services` text COLLATE utf8_unicode_ci COMMENT 'Service details',
  `rating_count` int(11) DEFAULT NULL COMMENT 'Total rating count',
  PRIMARY KEY (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Yellow page business details';

