<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

require_once APPPATH . 'third_party/htmldom.php';

/**
 * <p style="text-align:justify">
 * Library for scrapping yellow page data
 * </p>
 * @package Computer_Programming_Services
 * @subpackage Library
 * @category Library
 * @author Pronab Saha (pranab.su@gmail.com)
 * @license http://www.softwaredeveloperpro.com Software developer pro
 * @copyright (c) 2012, Software developer pro
 * @link http://www.softwaredeveloperpro.com
 */
class Yellowapi {
    /**
     * Initialize the Yellow API with needed information
     */
    public function __construct() {
        
    }

    /**
     * <p style="text-align:justify">
     * Search business listings
     * </p>
     * @access public
     * @param string $what Searched text
     * @param string $where Searced location
     * @param int $page Page number
     * @return array Returns business list array
     */
    public function scrap_business($what = '', $where = '', $page = 1) {
        $search_details = array();

        $what = str_replace(' ', '+', $what);
        $where = str_replace(' ', '+', $where);

        if ($page == 1) {
            $query = "http://www.yellowpages.com/$where/$what?menu_search=false&order=name";
        } else {
            $query = "http://www.yellowpages.com/$where/$what?menu_search=false&order=name&page=$page";
        }

        $data = $this->scrape_request($query);
        $data = $this->scrape_between($data, '<div id="results">', "<div>");
        $html = str_get_html($data);

        $search_details['details'] = array();

        if ($html) {
            foreach ($html->find('div.listing-content') as $e) {
                $name = $e->find('div.srp-business-name', 0)->plaintext;

                $address_node = $e->find('span.street-address', 0);
                $city_node = $e->find('span.locality', 0);
                $state_node = $e->find('span.region', 0);
                $zip_node = $e->find('span.postal-code', 0);
                $phn_node = $e->find('span.business-phone', 0);
                $rate_node = $e->find('p.average', 0);

                if ($address_node) {
                    $address = $address_node->plaintext;
                } else {
                    $address = '';
                }

                if ($city_node) {
                    $city = $city_node->plaintext;
                } else {
                    $city = '';
                }

                if ($state_node) {
                    $state = $state_node->plaintext;
                } else {
                    $state = '';
                }

                if ($zip_node) {
                    $zip = $zip_node->plaintext;
                } else {
                    $zip = '';
                }

                if ($phn_node) {
                    $phone = $phn_node->plaintext;
                } else {
                    $phone = '';
                }

                if ($rate_node) {
                    $rating = $rate_node->plaintext;
                } else {
                    $rating = '';
                }

                $url_node = $e->find('li.website-feature', 0);
                if ($url_node) {
                    $url = $url_node->innertext;
                    preg_match_all('/<a[^>]+href=([\'"])(.+?)\1[^>]*>/i', $url, $machtes);
                    $website = $machtes[2][0];
                    $website_parts = parse_url($website);
                    $website = $website_parts['host'];
                } else {
                    $website = '';
                }

                $categories = '';
                foreach ($e->find('ul.business-categories') as $ul) {
                    foreach ($ul->find('li') as $li) {
                        $categories .= $li->plaintext;
                    }
                }

                $data = array(
                    'business_name' => $name,
                    'business_category' => $categories,
                    'street_address' => $address,
                    'city' => $city,
                    'state' => $state,
                    'post_code' => $zip,
                    'phone' => $phone,
                    'average_rating' => $rating,
                    'company_url' => $website
                );


                array_push($search_details['details'], $data);
            }

            $search_details['pagination_text'] = $html->find('div.result-totals', 0)->plaintext;
        }

        return $search_details;
    }

    /**
     * <p style="text-align:justify">
     * Process scraping
     * </p>
     * @access protected
     * @param string $url Scrape query
     * @return mixed Returns raw scraped data
     */
    protected function scrape_request($url = '') {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
        $data = curl_exec($ch);
        curl_close($ch);
        return $data;
    }

    /**
     * <p style="text-align:justify">
     * Scrpe between whole page
     * </p>
     * @access protected
     * @param string $data Page data
     * @param string $start Start mark
     * @param string $end End mark
     * @return mixed Returns raw scraped between data
     */
    protected function scrape_between($data, $start, $end) {
        $data = stristr($data, $start);
        $data = substr($data, strlen($start));
        $stop = stripos($data, $end);
        $data = substr($data, 0, $stop);
        return $data;
    }

}