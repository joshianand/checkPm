<div class="search_container">
    <div class="row-fluid">
        <div class="span12">
            <div class="portlet box blue">
                <div class="portlet-title">
                    <h4><i class="icon-cogs"></i>Search yellow page</h4>
                    <div class="tools">
                        <a href="javascript:;" class="collapse"></a>
                    </div>
                </div>
                <div class="portlet-body">
                    <a href="#options" role="button" class="btn btn-primary blue" data-toggle="modal" style="margin-bottom: 5px;"><i class="icon-search"></i> New search</a>
                    <input id="csrf_portal" type="hidden" name="csrf_portal" value="<?php echo $token; ?>"/>
                    <div id="searchGrid" class="k-content"></div>
                </div>
            </div>
        </div>
    </div>

    <div id="options" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel1" aria-hidden="true" style="display: none;">
        <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
            <h3 id="myModalLabel1">New search</h3>
        </div>

        <div class="modal-body">
            <form id="frm_search_selection" name="frm_search_selection" class="form-horizontal" action="javascript:;" method="POST">
                <input id="csrf_portal" type="hidden" name="csrf_portal" value="<?php echo $token; ?>"/>

                <div class="control-group">
                    <label class="control-label">Select City</label>
                    <div class="controls">
                        <select id="citySelection" name="citySelection">
                            <?php foreach ($cities as $city) { ?>
                                <option value="<?php echo element('city_id', $city) ?>"><?php echo element('city_name', $city) . ", " . element('city_symbol', $city); ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>

                <div class="control-group">
                    <label class="control-label">Enter text</label>
                    <div class="controls">
                        <input type="text" value="" id="searchText" name="searchText">
                    </div>
                </div>
            </form>
        </div>

        <div class="modal-footer">
            <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove"></i> Close</button>
            <button class="btn yellow" onclick="newSearch();"><i class="icon-search"></i> Search</button>
        </div>
    </div>
</div>



<script type="text/x-kendo-template" id="template">
    <div class="businessDetails"></div>
</script>

<?php add_script('module_scripts/search_yellow_page/manage.yp.search.js'); ?>