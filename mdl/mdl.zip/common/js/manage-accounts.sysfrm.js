// JavaScript Document
// http://sysfrm.com
$('#show-all').click(function() {
  $('#accounts-data').toggle('slow', function() {
    //alert('Animation complete.');
  });
});