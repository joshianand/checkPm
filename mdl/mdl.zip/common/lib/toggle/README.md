[jQuery Switchbutton](http://naeka.github.com/jquery-switchbutton/) Switch buttons for websites
===============================================================================================

Enable switch mode button used on mobile devices for mode selection on your websites/webapps !

Requirements
------------

- jQuery (v 1.6.0+) - requires .prop()
- jQuery UI Widget (for Widget Factory)
- jQuery Templates

Use
---

Take a look to wiki and demo !
[Demo](http://naeka.github.com/jquery-switchbutton/)